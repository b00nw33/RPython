﻿from Polygon import *

class Rectangle( Polygon ) :
	def area( self ) :
		return self.width * self.height

