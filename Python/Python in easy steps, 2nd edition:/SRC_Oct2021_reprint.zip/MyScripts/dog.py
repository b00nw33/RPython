﻿def bark( pet = 'A Dog' ) :
	print( pet , 'Says WOOF!' )

def lick( pet = 'A Dog' ) :
	print( pet , 'Drinks Water' )

def nap( pet = 'A Dog' ) :
	print( pet , 'Sleeps In The Sun' )
