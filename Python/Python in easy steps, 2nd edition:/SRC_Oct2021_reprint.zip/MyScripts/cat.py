﻿def purr( pet = 'A Cat' ) :
	print( pet , 'Says MEOW!' )

def lick( pet = 'A Cat' ) :
	print( pet , 'Drinks Milk' )

def nap( pet = 'A Cat' ) :
	print( pet , 'Sleeps By The Fire' ) 