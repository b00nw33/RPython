﻿bool = True

if bool :
	print( 'Python In Easy Steps' )
else :
	# Statements to be inserted here.