﻿num = 3
print( num * 8 + 4 )