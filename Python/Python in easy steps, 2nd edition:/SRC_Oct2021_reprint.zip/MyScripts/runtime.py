﻿title = 'Python in easy steps'
print( titel )