﻿
# Initialize a variable with an integer value.
var = 8
print( var )

# Assign a float value to the variable.
var = 3.142
print( var )

# Assign a string value to the variable.
var = 'Python in easy steps'
print( var )

# Assign a boolean value to the variable.
var = True
print( var )

