//let myName = 'External Script'

function readName( ) {
  let myName = 'External Script' ; console.log( myName )
}

readName( )