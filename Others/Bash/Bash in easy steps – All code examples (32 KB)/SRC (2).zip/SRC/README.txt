### SRC ARCHIVE ############################################################
# 
# The contents of the archive are files that appear in 'Bash in easy steps'.
# It is provided for the reader's convenience only and without any warranty.
# Containing folders can be created with the mkdir command, e.g. mkdir Docs.
# Files can be moved to the folders with the mv command, e.g. mv greet.sh ~.
# Included media files are placeholders to minimize the size of the archive.
#
### www.ineasysteps.com ####################################################
