#include <stdio.h>

int main()
{
  printf( "...Text Output By Compiled C Program\n" );
  return 0;
}

