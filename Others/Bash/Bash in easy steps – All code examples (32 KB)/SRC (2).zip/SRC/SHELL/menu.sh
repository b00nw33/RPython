#!/bin/bash

select i in {A..C}
do
  echo $i
done
