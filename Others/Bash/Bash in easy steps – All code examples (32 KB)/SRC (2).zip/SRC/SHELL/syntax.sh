#!/bin/bash
echo 'Bash in easy steps
echo 'End'
