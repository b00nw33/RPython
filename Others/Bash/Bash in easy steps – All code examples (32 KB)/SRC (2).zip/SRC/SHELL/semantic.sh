#!/bin/bash
num=3
echo $(( num * 8 + 4 ))
