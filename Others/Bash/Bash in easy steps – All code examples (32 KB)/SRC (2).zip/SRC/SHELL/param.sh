#!/bin/bash

echo -n 'Please enter your name: '
read var
echo "Welcome to $@ , $var"
