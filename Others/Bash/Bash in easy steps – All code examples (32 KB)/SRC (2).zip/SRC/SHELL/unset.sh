#!/bin/bash

arr=(Alpha Bravo Charlie Delta Echo)

unset arr[1]

echo "Array arr[1]: ${arr[1]}"
echo "Array arr all: ${arr[@]}"
echo "Array arr length: ${#arr[@]}"
echo "Array arr elements filled: ${!arr[@]}"
