#!/bin/bash
title='Bash in easy steps'
echo $titel
echo 'End'
