#!/bin/bash

var='Hello World'
echo $var
