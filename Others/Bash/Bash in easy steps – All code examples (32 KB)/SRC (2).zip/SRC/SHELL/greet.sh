#!/bin/bash
# A Script to Greet the User.

echo -n 'Please enter your name: '
read username
echo "Welcome to $@ , $username"
