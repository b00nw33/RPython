#!/bin/bash

echo 'Sample shell script'!
