#!/bin/bash

function first
{
  echo 'Hello from the first function!'
}

cube5 ( )
{
  echo "5x5x5 = $(( 5*5*5 ))"
}

first
